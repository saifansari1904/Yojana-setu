/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ApplicationRecord, Scheme } from '../types';
import { useTranslation } from '../i18n';
import { ArrowRight, CheckCircle2, Clock, Send } from 'lucide-react';

interface ApplicationOverviewProps {
  summary: {
    total: number;
    readyToApply: number;
    preparing: number;
    applied: number;
    approved: number;
    records: { scheme: Scheme; record: ApplicationRecord }[];
  };
  onOpenTracker: () => void;
  onOpenWorkspace: (schemeId: string) => void;
  id?: string;
}

export const ApplicationOverview: React.FC<ApplicationOverviewProps> = ({
  summary,
  onOpenTracker,
  onOpenWorkspace,
  id = 'application-overview',
}) => {
  const { t } = useTranslation();

  return (
    <div
      id={id}
      className="bg-white dark:bg-[#151C19] rounded-xl border border-slate-200/90 shadow-sm p-6 flex flex-col justify-between"
    >
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#6F7A73] dark:text-[#8E9F97]">
            {t('applicationsTitle')}
          </h3>
          <span className="text-xs font-semibold text-[#3F4943] dark:text-[#C5D5CC] bg-[#F3F4F3] dark:bg-[#1E2924] px-2 py-0.5 rounded-full">
            {summary.total} Active
          </span>
        </div>

        {/* Status Count Bars */}
        <div className="grid grid-cols-3 gap-2.5 mb-5">
          <div className="p-3 rounded-lg bg-[#D4EFE1] dark:bg-[#1A382D] border border-[#D4EFE1] dark:border-[#22503E] text-center">
            <div className="text-xs font-semibold text-[#14453D] dark:text-[#4ADE80]">{t('readyToApply')}</div>
            <div className="text-xl font-bold text-[#0B302B] dark:text-[#D4EFE1] mt-1 tabular-nums">
              {summary.readyToApply}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#FEF3C7] dark:bg-[#3B2F14] border border-[#FCD34D]/40 text-center">
            <div className="text-xs font-semibold text-[#92610A] dark:text-[#FCD34D]">{t('preparing')}</div>
            <div className="text-xl font-bold text-amber-900 mt-1 tabular-nums">
              {summary.preparing}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-sky-50 border border-sky-100 text-center">
            <div className="text-xs font-semibold text-sky-800">{t('applied')}</div>
            <div className="text-xl font-bold text-sky-900 mt-1 tabular-nums">
              {summary.applied}
            </div>
          </div>
        </div>

        {/* Recent Active Application Rows */}
        {summary.records.length > 0 ? (
          <div className="space-y-2 mb-4">
            {summary.records.slice(0, 3).map(({ scheme, record }) => {
              const statusConfig = {
                'docs-ready': { label: t('readyToApply'), color: 'text-[#0F6B4C] dark:text-[#4ADE80] bg-[#C1E2D0] dark:bg-[#22503E]', icon: CheckCircle2 },
                'preparing': { label: t('preparing'), color: 'text-[#92610A] dark:text-[#FCD34D] bg-[#FEF3C7] dark:bg-[#3B2F14]', icon: Clock },
                'applied': { label: t('applied'), color: 'text-sky-700 bg-sky-100', icon: Send },
                'approved': { label: t('approved'), color: 'text-purple-700 bg-purple-100', icon: CheckCircle2 },
                'interested': { label: t('interested'), color: 'text-[#3F4943] dark:text-[#C5D5CC] bg-[#F3F4F3] dark:bg-[#1E2924]', icon: Clock },
              }[record.status] || { label: record.status, color: 'text-[#3F4943] dark:text-[#C5D5CC] bg-[#F3F4F3] dark:bg-[#1E2924]', icon: Clock };

              const StatusIcon = statusConfig.icon;

              return (
                <div
                  key={record.id}
                  onClick={() => onOpenWorkspace(scheme.id)}
                  className="p-2.5 rounded-lg border border-[#EAECEB] dark:border-[#24342D] hover:border-[#E2E2E0] dark:border-[#2A3C34] hover:bg-[#FAFAF9] dark:bg-[#151C19] transition-all cursor-pointer flex items-center justify-between gap-3 text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-semibold text-[#1A1C1B] dark:text-[#F0F4F2] truncate">
                      {scheme.code}
                    </div>
                    <div className="text-[11px] text-[#6F7A73] dark:text-[#8E9F97] truncate">
                      {scheme.name}
                    </div>
                  </div>

                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium shrink-0 ${statusConfig.color}`}
                  >
                    <StatusIcon className="w-3 h-3" />
                    {statusConfig.label}
                  </span>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-6 text-center text-xs text-[#6F7A73] dark:text-[#8E9F97]">
            {t('noApplicationsYet')}
          </div>
        )}
      </div>

      <button
        id="view-all-applications-btn"
        type="button"
        onClick={onOpenTracker}
        className="w-full mt-2 inline-flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-lg text-xs font-semibold text-[#3F4943] dark:text-[#C5D5CC] hover:text-[#1A1C1B] dark:text-[#F0F4F2] bg-[#FAFAF9] dark:bg-[#151C19] hover:bg-[#F3F4F3] dark:bg-[#1E2924] border border-[#E2E2E0] dark:border-[#24342D] transition-colors min-h-[44px]"
      >
        <span>{t('viewApplications')}</span>
        <ArrowRight className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
