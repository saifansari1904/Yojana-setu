/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DocumentStatus } from '../types';
import { useTranslation } from '../i18n';
import { FileCheck, AlertCircle, HelpCircle, ShieldCheck, ArrowRight } from 'lucide-react';

interface DocumentOverviewProps {
  summary: {
    prepared: number;
    needPreparation: number;
    unknown: number;
    reusable: { id: string; name: string; nameHi: string; status: DocumentStatus }[];
    applicationSpecific: { id: string; name: string; nameHi: string; schemeCode: string; status: DocumentStatus }[];
  };
  onOpenDocumentCenter: () => void;
  id?: string;
}

export const DocumentOverview: React.FC<DocumentOverviewProps> = ({
  summary,
  onOpenDocumentCenter,
  id = 'document-overview',
}) => {
  const { t, language } = useTranslation();
  const [activeTab, setActiveTab] = useState<'reusable' | 'specific'>('reusable');

  const statusBadge = (status: DocumentStatus) => {
    switch (status) {
      case 'PREPARED':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#0F6B4C] dark:text-[#4ADE80] bg-[#C1E2D0] dark:bg-[#22503E] px-2 py-0.5 rounded-full">
            <FileCheck className="w-3 h-3" />
            {t('prepared')}
          </span>
        );
      case 'NEED_PREPARATION':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#92610A] dark:text-[#FCD34D] bg-[#FEF3C7] dark:bg-[#3B2F14] px-2 py-0.5 rounded-full">
            <AlertCircle className="w-3 h-3" />
            {t('needPreparation')}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#516A5F] dark:text-[#9EB0A7] bg-[#F3F4F3] dark:bg-[#1E2924] px-2 py-0.5 rounded-full">
            <HelpCircle className="w-3 h-3" />
            {t('unknown')}
          </span>
        );
    }
  };

  return (
    <div
      id={id}
      className="bg-white dark:bg-[#151C19] rounded-xl border border-slate-200/90 shadow-sm p-6 flex flex-col justify-between"
    >
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#6F7A73] dark:text-[#8E9F97]">
            {t('documentCenterTitle')}
          </h3>
          <span className="text-xs text-[#6F7A73] dark:text-[#8E9F97] font-medium">Readiness Tracker</span>
        </div>

        {/* Readiness Count Metrics */}
        <div className="grid grid-cols-3 gap-2.5 mb-4">
          <div className="p-3 rounded-lg bg-[#D4EFE1] dark:bg-[#1A382D] border border-[#D4EFE1] dark:border-[#22503E] text-center">
            <div className="text-xs font-semibold text-[#14453D] dark:text-[#4ADE80]">{t('prepared')}</div>
            <div className="text-xl font-bold text-[#0B302B] dark:text-[#D4EFE1] mt-1 tabular-nums">
              {summary.prepared}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#FEF3C7] dark:bg-[#3B2F14] border border-[#FCD34D]/40 text-center">
            <div className="text-xs font-semibold text-[#92610A] dark:text-[#FCD34D]">{t('needPreparation')}</div>
            <div className="text-xl font-bold text-amber-900 mt-1 tabular-nums">
              {summary.needPreparation}
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#FAFAF9] dark:bg-[#151C19] border border-[#E2E2E0] dark:border-[#24342D] text-center">
            <div className="text-xs font-semibold text-[#3F4943] dark:text-[#C5D5CC]">{t('unknown')}</div>
            <div className="text-xl font-bold text-[#1A1C1B] dark:text-[#F0F4F2] mt-1 tabular-nums">
              {summary.unknown}
            </div>
          </div>
        </div>

        {/* Tab Toggle: Reusable vs Application Specific */}
        <div className="flex border-b border-[#E2E2E0] dark:border-[#24342D] mb-3 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('reusable')}
            className={`pb-2 px-3 font-semibold transition-colors border-b-2 -mb-px ${
              activeTab === 'reusable'
                ? 'border-[#14453D] text-[#1A1C1B] dark:text-[#F0F4F2]'
                : 'border-transparent text-[#6F7A73] dark:text-[#8E9F97] hover:text-[#3F4943] dark:text-[#C5D5CC]'
            }`}
          >
            {t('reusableDocuments')} ({summary.reusable.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('specific')}
            className={`pb-2 px-3 font-semibold transition-colors border-b-2 -mb-px ${
              activeTab === 'specific'
                ? 'border-[#14453D] text-[#1A1C1B] dark:text-[#F0F4F2]'
                : 'border-transparent text-[#6F7A73] dark:text-[#8E9F97] hover:text-[#3F4943] dark:text-[#C5D5CC]'
            }`}
          >
            {t('applicationSpecificDocuments')} ({summary.applicationSpecific.length})
          </button>
        </div>

        {/* Document Items List */}
        <div className="space-y-1.5 mb-4 max-h-[160px] overflow-y-auto pr-1">
          {activeTab === 'reusable' ? (
            summary.reusable.length > 0 ? (
              summary.reusable.map(doc => (
                <div
                  key={doc.id}
                  className="flex items-center justify-between p-2 rounded-lg bg-[#FAFAF9] dark:bg-[#151C19] text-xs border border-[#EAECEB] dark:border-[#24342D]"
                >
                  <span className="font-medium text-[#14453D] dark:text-[#E8EFEA] truncate pr-2">
                    {language === 'hi' ? doc.nameHi : doc.name}
                  </span>
                  {statusBadge(doc.status)}
                </div>
              ))
            ) : (
              <div className="text-xs text-[#6F7A73] dark:text-[#8E9F97] py-3 text-center">No reusable documents mapped.</div>
            )
          ) : summary.applicationSpecific.length > 0 ? (
            summary.applicationSpecific.map(doc => (
              <div
                key={doc.id}
                className="flex items-center justify-between p-2 rounded-lg bg-[#FAFAF9] dark:bg-[#151C19] text-xs border border-[#EAECEB] dark:border-[#24342D]"
              >
                <div className="truncate pr-2">
                  <span className="font-bold text-[#516A5F] dark:text-[#9EB0A7] mr-1.5">[{doc.schemeCode}]</span>
                  <span className="font-medium text-[#14453D] dark:text-[#E8EFEA]">
                    {language === 'hi' ? doc.nameHi : doc.name}
                  </span>
                </div>
                {statusBadge(doc.status)}
              </div>
            ))
          ) : (
            <div className="text-xs text-[#6F7A73] dark:text-[#8E9F97] py-3 text-center">No specific documents mapped.</div>
          )}
        </div>
      </div>

      <div>
        {/* Strict Privacy Badge */}
        <div className="flex items-center gap-1.5 text-[11px] text-[#6F7A73] dark:text-[#8E9F97] bg-[#FAFAF9] dark:bg-[#151C19] p-2 rounded-md mb-3 border border-[#EAECEB] dark:border-[#24342D]">
          <ShieldCheck className="w-3.5 h-3.5 text-[#16A34A] dark:text-[#34D399] shrink-0" />
          <span className="leading-tight">{t('privacyGuarantee')}</span>
        </div>

        <button
          id="view-document-center-btn"
          type="button"
          onClick={onOpenDocumentCenter}
          className="w-full inline-flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-lg text-xs font-semibold text-[#3F4943] dark:text-[#C5D5CC] hover:text-[#1A1C1B] dark:text-[#F0F4F2] bg-[#FAFAF9] dark:bg-[#151C19] hover:bg-[#F3F4F3] dark:bg-[#1E2924] border border-[#E2E2E0] dark:border-[#24342D] transition-colors min-h-[44px]"
        >
          <span>{t('viewDocumentCenter')}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
